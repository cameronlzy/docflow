export const operatorReplace = (match) => `$${match}`;
