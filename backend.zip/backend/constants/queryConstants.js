export const EXCLUDED_QUERIES = ["page", "sort", "limit", "fields"]

export const MONGO_REGEX = /\b(gte|gt|lt|lte)\b/g
